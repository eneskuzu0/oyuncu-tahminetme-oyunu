import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import json, random, os, sys

LOGO_PATHS = {
    "Premier Lig": "logos/premier lig.png",
    "La Liga": "logos/la liga.png",
    "Bundesliga": "logos/bundesliga.png",
    "Ligue 1": "logos/ligue 1.png",
    "Serie A": "logos/serie A.png"
}

def load_players(file):
    with open(file, "r", encoding="utf-8") as f:
        return json.load(f)

def clean_name(name):
    table = str.maketrans("çğıöşü", "cgiosu")
    return ''.join([c for c in name.translate(table).lower() if c.isalpha()])

class PlayerGuessGame(tk.Tk):
    def __init__(self, datafile):
        super().__init__()
        self.players = load_players(datafile)
        self.title("Futbolcu Tahmin Oyunu")
        self.config(bg="#fafafa")
        self.logo_imgs = {}
        self.menu_frame = None
        self.game_frame = None
        self.start_menu()

    def start_menu(self):
        if self.menu_frame: self.menu_frame.destroy()
        if self.game_frame: self.game_frame.destroy()
        self.menu_frame = tk.Frame(self, bg="#fafafa")
        self.menu_frame.place(relx=0.5, rely=0.5, anchor="center")
        # Daha büyük ve yer kaplayan başlık
        tk.Label(
            self.menu_frame,
            text="Bir lig seçin:".upper(),
            font=("Arial", 36, "bold"), 
            bg="#fafafa",
            fg="#1565c0",
            pady=32
        ).pack()
        ligler = [lig for lig in LOGO_PATHS if any(p["lig"] == lig for p in self.players)]
        row = tk.Frame(self.menu_frame, bg="#fafafa")
        row.pack(pady=40)
        for lig in ligler:
            logo = LOGO_PATHS[lig]
            img = Image.open(logo).resize((120, 120))
            tkimg = ImageTk.PhotoImage(img)
            self.logo_imgs[lig] = tkimg
            btn = tk.Button(row, image=tkimg,
                            bg="white", width=140, height=140, bd=2, relief="ridge",
                            cursor="hand2",
                            command=lambda l=lig: self.start_game(l))
            btn.pack(side="left", padx=36)
        
    def start_game(self, lig):
        self.menu_frame.destroy()
        self.game_frame = GameFrame(self, [p for p in self.players if p["lig"] == lig], lig, self.start_menu)
        self.game_frame.place(relx=0.5, rely=0.5, anchor="center")

class GameFrame(tk.Frame):
    def __init__(self, master, pool, lig, back_fn):
        super().__init__(master, bg="#fafafa", width=1000, height=600)
        self.pool = pool
        self.lig = lig
        self.back_fn = back_fn
        self.setup()
        self.new_round()

    def setup(self):
        self.pack_propagate(0)
        top = tk.Frame(self, bg="#fafafa"); top.pack(pady=6, fill="x")
        self.lbl_hak = tk.Label(top, text="", font=("Arial", 15, "bold"), bg="#fafafa"); self.lbl_hak.pack(side="left", padx=10)
        self.lbl_lig = tk.Label(top, text=f"Lig: {self.lig}", font=("Arial", 15, "bold"), bg="#fafafa", fg="#1565c0")
        self.lbl_lig.pack(side="left", padx=10)
        self.frm_word = tk.Frame(self, bg="#fafafa"); self.frm_word.pack(pady=10)
        self.frm_hints = tk.Frame(self, bg="#e0f2f1"); self.frm_hints.pack(pady=10)
        self.frm_guesses = tk.Frame(self, bg="#fafafa"); self.frm_guesses.pack(pady=10)
        self.btn_menu = tk.Button(self, text="Ana Menüye Dön", font=("Arial", 15), bg="#b3e5fc", command=self.back_fn)
        self.master.bind("<Key>", self.key_press)

    def new_round(self):
        self.player = random.choice(self.pool)
        self.answer = clean_name(self.player['isim'])
        self.hak = 5
        self.chars = [""] * len(self.answer)
        self.locks = [None] * len(self.answer)
        self.guess_idx = 0
        self.show_word()
        self.frm_guesses.destroy(); self.frm_guesses = tk.Frame(self, bg="#fafafa"); self.frm_guesses.pack(pady=10)
        self.ipucu_step = 0
        self.show_hints()
        self.lbl_hak.config(text=f"Kalan Hak: {self.hak}")
        self.btn_menu.place_forget()

    def show_word(self):
        for w in self.frm_word.winfo_children(): w.destroy()
        for i, ch in enumerate(self.chars):
            l = self.locks[i].upper() if self.locks[i] else (ch.upper() if ch else "_")
            b = "#4caf50" if self.locks[i] else "white"
            f = "white" if self.locks[i] else "black"
            lbl = tk.Label(self.frm_word, text=l, width=2, font=("Consolas", 22, "bold"),
                           relief="ridge", bd=4, bg=b, fg=f)
            lbl.pack(side="left", padx=6)

    def show_hints(self):
        for w in self.frm_hints.winfo_children(): w.destroy()
        hints = [("Mevki", self.player["mevki"]), ("Yaş", self.player["yaş"]),
                 ("Takım", self.player["takım"]), ("Uyruk", self.player["uyruk"])]
        tk.Label(self.frm_hints, text="İpucu", font=("Arial", 15, "bold"), bg="#e0f2f1").pack()
        for i in range(min(self.ipucu_step, 4)):
            tk.Label(self.frm_hints, text=f"{hints[i][0]}: {hints[i][1]}", font=("Arial", 13), bg="#e0f2f1").pack(anchor="w")
        if self.hak == 0:
            tk.Label(self.frm_hints, text=f"Doğru: {self.player['isim']}", font=("Arial", 15, "bold"), fg="red", bg="#e0f2f1").pack()

    def key_press(self, e):
        if self.hak == 0: return
        if e.keysym == "BackSpace":
            while self.guess_idx > 0 and self.locks[self.guess_idx-1] is not None:
                self.guess_idx -= 1
            if self.guess_idx > 0: self.guess_idx -= 1
            self.chars[self.guess_idx] = ""
            self.show_word()
        elif e.keysym == "Return":
            if "" not in self.chars: self.check_guess()
        elif e.char.isalpha():
            while self.guess_idx < len(self.chars) and self.locks[self.guess_idx] is not None:
                self.guess_idx += 1
            if self.guess_idx < len(self.chars):
                self.chars[self.guess_idx] = clean_name(e.char)[0]
                self.guess_idx += 1
                self.show_word()
            if "" not in self.chars: self.check_guess()

    def check_guess(self):
        guess = ''.join([self.locks[i] if self.locks[i] else self.chars[i] for i in range(len(self.answer))])
        colors = ["#cccccc"] * len(self.answer)
        count = {}
        for h in self.answer: count[h] = count.get(h, 0) + 1
        for i, (g, a) in enumerate(zip(guess, self.answer)):
            if g == a: colors[i] = "#4caf50"; count[g] -= 1
        for i, g in enumerate(guess):
            if colors[i] == "#4caf50": continue
            if g in self.answer and count.get(g, 0) > 0:
                colors[i] = "#ffd600"; count[g] -= 1
        f = tk.Frame(self.frm_guesses, bg="#fafafa")
        for i, ch in enumerate(guess):
            tk.Label(f, text=ch.upper(), width=2, font=("Consolas", 16, "bold"),
                     relief="ridge", bd=2, bg=colors[i]).pack(side="left", padx=2)
            if colors[i] == "#4caf50": self.locks[i] = ch
        f.pack(pady=2)
        self.chars = [self.locks[i] if self.locks[i] else "" for i in range(len(self.answer))]
        self.guess_idx = 0
        self.show_word()
        if guess == self.answer:
            messagebox.showinfo("Doğru!", f"Cevap: {self.player['isim']}")
            self.new_round()
            return
        self.hak -= 1; self.lbl_hak.config(text=f"Kalan Hak: {self.hak}")
        self.ipucu_step = 5 - self.hak
        self.show_hints()
        if self.hak == 0:
            self.lbl_lig.config(text="Bitti. Ana menüye dön.")
            self.btn_menu.place(relx=0.5, rely=0.93, anchor="center")

if __name__ == "__main__":
    datafile = "secili_takim_oyuncular.json"
    if not os.path.isfile(datafile):
        tk.Tk().withdraw()
        messagebox.showerror("Eksik Dosya", f"{datafile} bulunamadı!")
        sys.exit()
    PlayerGuessGame(datafile).mainloop()
